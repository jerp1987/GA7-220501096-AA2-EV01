
package dbcrud;

import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;

public class dbcruddelete {

    public static void main(String[] args) {

        String usuario = "root";
        String password = "1026553655";
        String url = "jdbc:mysql://localhost:3306/dbcrud";
        Connection conexion = null;
        Statement statement = null;
        ResultSet rs = null;

        try {
            // Cargar el driver de MySQL
            Class.forName("com.mysql.cj.jdbc.Driver");

            // Establecer la conexión
            conexion = DriverManager.getConnection(url, usuario, password);
            statement = conexion.createStatement();

            // Ejecutar la instrucción DELETE
            String deleteQuery = "DELETE FROM usuario WHERE CEDULA = '100888999'";
            statement.executeUpdate(deleteQuery);
            System.out.println("Registro eliminado correctamente.");

            // Ejecutar la instrucción SELECT y mostrar resultados
            String selectQuery = "SELECT * FROM usuario";
            rs = statement.executeQuery(selectQuery);

            while (rs.next()) {
                System.out.println(rs.getString("NOMBRE") + " " + rs.getString("APELLIDO"));
            }

        } catch (ClassNotFoundException ex) {
            Logger.getLogger(dbcruddelete.class.getName()).log(Level.SEVERE, "Driver no encontrado", ex);
        } catch (SQLException ex) {
            Logger.getLogger(dbcruddelete.class.getName()).log(Level.SEVERE, "Error en la consulta SQL", ex);
        } finally {
            // Cerrar recursos
            try {
                if (rs != null) rs.close();
                if (statement != null) statement.close();
                if (conexion != null) conexion.close();
            } catch (SQLException ex) {
                Logger.getLogger(dbcruddelete.class.getName()).log(Level.SEVERE, "Error al cerrar recursos", ex);
            }
        }
    }
}

    
