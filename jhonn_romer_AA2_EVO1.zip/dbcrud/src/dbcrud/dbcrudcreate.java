

package dbcrud;

/**
 *
 * @author Usuario/ librerias del proyecto 
 */
import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;
public class dbcrudcreate {

    /**
     * @param args the command line arguments/ conexion BDCRUD Y SUS ARGUMENTOS 
     */
 
    public static void main(String[] args) {
        
        String usuario = "root";
        String password = "1026553655";
        String url = "jdbc:mysql://localhost:3306/dbcrud";
        Connection conexion;
        Statement statement;
        ResultSet rs;

        try {                         
            Class.forName("com.mysql.cj.jdbc.Driver");

        } catch (ClassNotFoundException ex) {
            Logger.getLogger(dbcrud.class.getName()).log(Level.SEVERE, null, ex);
        }
        try {
            conexion = DriverManager.getConnection(url,usuario,password);
            statement = conexion. createStatement();
            statement.executeUpdate("INSERT INTO usuario (NOMBRE, APELLIDO,CORREO,CEDULA) VALUES ('yarledys', 'paternina','yarledys@gmail.com','100888999')");
            rs = statement.executeQuery("SELECT * FROM usuario");
            rs.next();
             do{
                 System.out.println(rs.getString("NOMBRE") + ":" + rs.getString("APELLIDO"));
  
             }while(rs.next());
             
            
            
        } catch (SQLException ex) {
            Logger.getLogger(dbcrud.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
    

