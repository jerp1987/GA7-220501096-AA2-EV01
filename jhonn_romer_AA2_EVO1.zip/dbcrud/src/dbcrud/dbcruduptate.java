package dbcrud;

import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;

public class dbcruduptate {

    public static void main(String[] args) {

        String usuario = "root";
        String password = "1026553655";
        String url = "jdbc:mysql://localhost:3306/dbcrud";
        Connection conexion = null;
        Statement statement = null;
        ResultSet rs = null;

        try {
            // Cargar el driver de MySQL
            Class.forName("com.mysql.cj.jdbc.Driver");

            // Establecer la conexión
            conexion = DriverManager.getConnection(url, usuario, password);
            statement = conexion.createStatement();

            // Ejecutar la consulta UPDATE
            String updateQuery = "UPDATE usuario SET NOMBRE = 'PEDRO', APELLIDO = 'HERNANDEZ', CEDULA = '1032888111' WHERE id = 14";
            int rowsAffected = statement.executeUpdate(updateQuery);
            System.out.println("Filas actualizadas: " + rowsAffected);

            // Ejecutar la consulta SELECT para mostrar los resultados
            String selectQuery = "SELECT * FROM usuario";
            rs = statement.executeQuery(selectQuery);

            while (rs.next()) {
                System.out.println(rs.getString("NOMBRE") + ": " + rs.getString("APELLIDO"));
            }

        } catch (ClassNotFoundException ex) {
            Logger.getLogger(dbcruduptate.class.getName()).log(Level.SEVERE, "Driver no encontrado", ex);
        } catch (SQLException ex) {
            Logger.getLogger(dbcruduptate.class.getName()).log(Level.SEVERE, "Error en la consulta SQL", ex);
        } finally {
            // Cerrar recursos
            try {
                if (rs != null) rs.close();
                if (statement != null) statement.close();
                if (conexion != null) conexion.close();
            } catch (SQLException ex) {
                Logger.getLogger(dbcruduptate.class.getName()).log(Level.SEVERE, "Error al cerrar recursos", ex);
            }
        }
    }
}

